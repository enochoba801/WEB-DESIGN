
            document.getElementById('registrationForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent form submission
            
            // You can add your validation logic here
            // For example:
            var firstName = document.getElementById('first-name').value;
            var lastName = document.getElementById('last-name').value;
            var email = document.getElementById('email').value;
            var password = document.getElementById('new-password').value;
            var profilePicture = document.getElementById('profile-picture').value;
            var age = document.getElementById('age').value;
            var level = document.getElementById('level').value;

            // Here, you can validate each field, and if any field is invalid, display an error message
            // If all fields are valid, you can submit the form using AJAX or simply let it submit normally
            // For simplicity, let's just alert the values for now
            alert('First Name: ' + firstName + '\nLast Name: ' + lastName + '\nEmail: ' + email + '\nPassword: ' + password + '\nProfile Picture: ' + profilePicture + '\nAge: ' + age + '\nLevel: ' + level);
        });

